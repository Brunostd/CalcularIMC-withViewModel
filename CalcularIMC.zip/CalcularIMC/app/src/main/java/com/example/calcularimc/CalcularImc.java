package com.example.calcularimc;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.text.DecimalFormat;

public class CalcularImc extends ViewModel {

    private MutableLiveData<String> imc;
    double peso, altura;

    public CalcularImc() {
        imc = new MutableLiveData<>();
        imc.postValue("0");
    }

    public void calculandoImc(Double auxPeso, Double auxAltura){
        Double recebeCalculo = auxPeso / (auxAltura * auxAltura );
        imc.setValue(String.valueOf(recebeCalculo));
    }

    public LiveData<String> getImc(){
        return imc;
    }

}
