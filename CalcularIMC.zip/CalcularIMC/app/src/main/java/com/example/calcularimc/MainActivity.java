package com.example.calcularimc;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    private CalcularImc calcularImc;
    private EditText editTextPeso, editTextAltura;
    private TextView textResultado;
    private Button buttonCalcular;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextPeso    = findViewById(R.id.editTextPeso);
        editTextAltura  = findViewById(R.id.editTextAltura);
        textResultado   = findViewById(R.id.textResultado);
        buttonCalcular  = findViewById(R.id.button);


        calcularImc = new ViewModelProvider(this).get(CalcularImc.class);


        buttonCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularImc.calculandoImc(Double.parseDouble(editTextPeso.getText().toString()),
                        Double.parseDouble(editTextAltura.getText().toString()));

                double recebeImc = Double.parseDouble(calcularImc.getImc().getValue());
                DecimalFormat decimalFormat = new DecimalFormat("#.##");

                textResultado.setText(String.valueOf(decimalFormat.format(recebeImc)));
            }
        });

    }
}